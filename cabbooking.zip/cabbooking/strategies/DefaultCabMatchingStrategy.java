package com.ajitesh.cabbooking.strategies;

import com.ajitesh.cabbooking.model.Cab;
import com.ajitesh.cabbooking.model.Location;
import com.ajitesh.cabbooking.model.Rider;
import lombok.NonNull;

import java.util.List;

public class DefaultCabMatchingStrategy implements CabMatchingStrategy {

    @Override
    public Cab matchCabToRider(

            @NonNull final Rider rider,
            @NonNull final List<Cab> candidateCabs,
            @NonNull final Location fromPoint,
            @NonNull final Location toPoint ){
       /* return candidateCabs.stream()
                .filter(cab -> cab.getCurrentTrip() == null).findAny();*/

        if (candidateCabs.isEmpty()) {
            return null;
        }
        return candidateCabs.get(0);
    }

}
