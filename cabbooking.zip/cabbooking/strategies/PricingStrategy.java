package com.ajitesh.cabbooking.strategies;

import com.ajitesh.cabbooking.model.Location;

public interface PricingStrategy {
    Double findPrice(Location fromPoint, Location toPoint);
}
