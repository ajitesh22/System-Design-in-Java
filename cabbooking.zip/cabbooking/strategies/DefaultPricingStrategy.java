package com.ajitesh.cabbooking.strategies;

import com.ajitesh.cabbooking.model.Location;

public class DefaultPricingStrategy implements  PricingStrategy {

    public static final  Double PER_KM_RATE = 10.0;

    @Override
    public Double findPrice(Location fromPiont, Location toPoint){ return fromPiont.Distance(toPoint) * PER_KM_RATE;}
}
