package com.ajitesh.cabbooking.strategies;

import com.ajitesh.cabbooking.model.Cab;
import com.ajitesh.cabbooking.model.Location;
import com.ajitesh.cabbooking.model.Rider;

import java.util.List;

public interface CabMatchingStrategy {

    Cab matchCabToRider(Rider rider, List<Cab> candidateCabs, Location fromPoint, Location toPoint);
}
