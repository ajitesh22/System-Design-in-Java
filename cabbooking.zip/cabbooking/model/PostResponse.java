package com.ajitesh.cabbooking.model;

public class PostResponse {
}
