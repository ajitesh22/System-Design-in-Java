package com.ajitesh.cabbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabBookingTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(CabBookingTestApplication.class, args);
    }

}
