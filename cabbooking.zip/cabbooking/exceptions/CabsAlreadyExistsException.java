package com.ajitesh.cabbooking.exceptions;

public class CabsAlreadyExistsException extends RuntimeException {}
