package com.ajitesh.cabbooking.exceptions;

public class RiderAlreadyExistsException extends RuntimeException {}