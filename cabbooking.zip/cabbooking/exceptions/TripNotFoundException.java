package com.ajitesh.cabbooking.exceptions;

public class TripNotFoundException extends RuntimeException {}
