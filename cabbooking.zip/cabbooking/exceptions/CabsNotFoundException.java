package com.ajitesh.cabbooking.exceptions;

public class CabsNotFoundException extends RuntimeException {}