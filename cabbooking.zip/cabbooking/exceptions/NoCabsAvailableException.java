package com.ajitesh.cabbooking.exceptions;

public class NoCabsAvailableException extends RuntimeException {}